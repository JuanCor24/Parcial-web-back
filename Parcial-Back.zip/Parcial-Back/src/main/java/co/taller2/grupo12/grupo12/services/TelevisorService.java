package co.taller2.grupo12.grupo12.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.taller2.grupo12.grupo12.ApplicationRepository.TelevisorRepository;
import co.taller2.grupo12.grupo12.DTOS.TelevisorDTO;
import co.taller2.grupo12.grupo12.entity.Televisor;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;




public class TelevisorService {
    
}
