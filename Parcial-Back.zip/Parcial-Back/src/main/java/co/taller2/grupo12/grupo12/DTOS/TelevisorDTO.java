package co.taller2.grupo12.grupo12.DTOS;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import co.taller2.grupo12.grupo12.enum.Resolucion;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor


public class TelevisorDTO {
    private String marca;
    private Long tamano_pantalla;
    private Resolucion resolucion;
    private String descripcion;
    private String funciones_adicionales;   
    private double precio;
    private String descripcion_garantia;   
    private LocalDate fechacreacion;
}
