package co.taller2.grupo12.grupo12.Controller;


import co.taller2.grupo12.grupo12.DTOS.TelevisorDTO;
import co.taller2.grupo12.grupo12.services.TelevisorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/televisores")


public class TelevisorController {
    @Autowired
    private TelevisorService televisorService;

    @GetMapping
    public ResponseEntity<List<TelevisorDTO>> getAllCelulares() {
        List<TelevisorDTO> celulares = televisorService.getAllTelevisores();
        return new ResponseEntity<>(celulares, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<TelevisorDTO> createCelular(@RequestBody TelevisorDTO televisorDTO) {
        TelevisorDTO createdTelevisor = TelevisorService.createTelevisor(televisorDTO);
        return new ResponseEntity<>(createdTelevisor, HttpStatus.CREATED);
    }

}
