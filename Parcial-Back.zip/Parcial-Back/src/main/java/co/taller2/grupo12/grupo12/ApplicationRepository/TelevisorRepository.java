package co.taller2.grupo12.grupo12.ApplicationRepository;
import org.springframework.data.repository.CrudRepository;

import co.taller2.grupo12.grupo12.entity.Televisor;



public interface TelevisorRepository extends CrudRepository<Televisor, String>{
    
}
